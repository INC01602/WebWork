sap.ui.define([
	"com/MessageStripTest/test/unit/controller/View1.controller"
], function () {
	"use strict";
});