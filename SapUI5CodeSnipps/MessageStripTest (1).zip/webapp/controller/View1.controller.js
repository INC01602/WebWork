sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'sap/m/MessageStrip'
], function (Controller, MessageStrip) {
	"use strict";

	return Controller.extend("com.MessageStripTest.controller.View1", {
		onInit: function () {

		},

		showSuccessMsgStrip: function () {
			// var oMsgStrip = document.getElementById("msgSuccessStrip");
			var oMsgStrip = sap.ui.getCore().byId("msgSuccessStrip");

			if (oMsgStrip) {
				oMsgStrip.destroy();
			}

			this._generateSuccessMsgStrip();

			setTimeout(function () {
				var oMStrip = sap.ui.getCore().byId("msgSuccessStrip");
				oMStrip.close();
			}, 3000);
		},

		showErrorMsgStrip: function () {
			var oMsgStrip = sap.ui.getCore().byId("msgErrorStrip");

			if (oMsgStrip) {
				oMsgStrip.destroy();
			}

			this._generateErrorMsgStrip();

			setTimeout(function () {
				var oMStrip = sap.ui.getCore().byId("msgErrorStrip");
				oMStrip.close();
			}, 3000);
		},

		_generateSuccessMsgStrip: function () {
			var oVBox = this.getView().byId("messageStripAccomodate"),

				aTypes = "Success",
				sText = "Measurement documents created Successfully",

				oMsgStrip = new MessageStrip("msgSuccessStrip", {
					text: sText,
					customIcon: "sap-icon://sys-enter-2",
					showIcon: true,
					type: aTypes
				});
			oMsgStrip.addStyleClass("SuccessMsgStrip");
			oVBox.insertItem(oMsgStrip, 0);
		},

		_generateErrorMsgStrip: function () {
			var oVBox = this.getView().byId("messageStripAccomodate"),

				aTypes = "Error",
				sText = "Measurement documents not created Successfully",

				oMsgStrip = new MessageStrip("msgErrorStrip", {
					text: sText,
					customIcon: "sap-icon://sys-cancel-2",
					showIcon: true,
					type: aTypes
				});
			oMsgStrip.addStyleClass("ErrorMsgStrip");
			oVBox.insertItem(oMsgStrip, 0);
		}

	});
});